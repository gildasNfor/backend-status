package com.example.restservice.users;

import org.springframework.web.multipart.MultipartFile;

import java.util.List;

public interface UserInterface {
    public User createUser(int userNumber, MultipartFile file, String userBio) throws Exception;

    public User getOneUser(int userNumber);

    public List<User> getAllUsers();

    public User deleteOneUser(int userNumber);
}
