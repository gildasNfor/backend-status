package com.example.restservice.socket;

import lombok.Data;

@Data
public class Message {

    private String msg;
}
